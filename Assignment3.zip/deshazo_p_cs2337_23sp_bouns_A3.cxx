//  CS 2337
//  2023 Spring
//  Assignment 3
//  Name: Preston DeShazo
//  Buff-Id: 1122965
//
//  Note: 
//      1. The only parts of this file to modify is to add your code to the
//         functions to be implemented.
//      2. You may only use the functions pow and sqrt from <cmath> for
//         implementing the stdev function

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <cassert>

using namespace std;

//  Note: do not use sort
//  Precondition: n > 0, A contains n numbers.
//  Postcondition: the smallest (min) number in A is returned.
double min(double A[], size_t n)
{
    double min = A[0];
    for (size_t i = 1; i < n; i++) {
        if (A[i] < min) {
            min = A[i];
        }
    }
    return min;
}

//  Note: do not use sort
//  Precondition: n > 0, A contains n numbers.
//  Postcondition: The largest (max) number in A is returned.
double max(double A[], size_t n)
{
    double max = A[0];
    for (size_t i = 1; i < n; i++) {
        if (A[i] > max) {
            max = A[i];
        }
    }
    return max;
}

//  Precondition: n > 0, A contains n numbers and A is sorted from smallest to
//                largest (sort will be applied to A so that when A is passed
//                into this function, A is sorted from least to greatest number).
//  Postcondition: The middle number is returned when n is odd.
//                 Else, the average of the two middle numbers is returned when n
//                 is even.
double med(double A[], size_t n)
{
    double median;
    size_t mid = n / 2;
    if (n % 2 == 0) {
        median = (A[mid - 1] + A[mid]) / 2.0;
    }
    else {
        median = A[mid];
    }
    return median;

}


//  Precondition: n > 0, A contains n numbers.
//  Postcondition: The average (or mean) of the numbers in A is returned.
double avg(double A[], size_t n)
{
   double sum = 0.0;
    for (size_t i = 0; i < n; i++) {
        sum += A[i];
    }
    return sum / n;
}

//  Note: see attached pdf file that shows the standard deviation calculation
//  Precondition: n > 0, A contains n numbers.
//  Postcondition: The population standard deviation of the numbers in A is returned.
double stdev(double A[], size_t n)
{
    double mean = avg(A, n);
    double sum = 0.0;
    for (size_t i = 0; i < n; i++) {
        sum += pow((A[i] - mean), 2);
    }
    return sqrt(sum / n);
}

// BONUS: 10 points
// This function goes through the n elements in array A and for each of
// the following intervals, counts the number of elements that fall within
// each respective interval.
//
//  [0,10),[10,20),[20,30),[30,40),[40,50),[50,60),[60,70),[70,80),[80,90),[90,100]
//
// Here, [ means inclusive and ) means exclusive. For example, [50, 60) denotes
// all numbers greater than or equal to 50 and less than 60. As an example,
// suppose the numbers in the sequence are (in no particular order):
//      2, 91.1, 30, 32, 5.3, 40, 41, 88.8, 63, 45.1, 45, 3, 99, 30
//
// Then, once the counts are collected for the above example, the program
// will print out the following to the terminal:
//   [0,10)   {.21} ***
//   [10,20)
//   [20,30)
//   [30,40)  {.21} ***
//   [40,50)  {.29} ****
//   [50,60)
//   [60,70)  {.07} *
//   [70,80)
//   [80,90)  {.07} *
//   [90,100] {.14} **
//
// The numbers in the curly brackets denote a percentage, which is the count
// for the range divided by total number of elements. For example, the interval
// [30,40) has 3 items (30,30,32) that fall in this interval
// (i.e., 3 asterisks are printed) and the percentage is 3/14 = .21 
// (print two significant digits after the decimal - you can do
// rounding, floor, ceiling, etc..., which can be found in <cmath>). 
// Notice that the dynamic aspects of the print out are the percentages
// and number of asterisks denoting counts.
//
void print_dist(double A[], size_t n)
{
// Initialize an array to keep track of the counts in each interval
    int counts[10] = {0};

    // Iterate through the elements of the array and update the counts
    for (size_t i = 0; i < n; i++)
    {
        double val = A[i];

        if (val >= 0 && val < 10)
        {
            counts[0]++;
        }
        else if (val >= 10 && val < 20)
        {
            counts[1]++;
        }
        else if (val >= 20 && val < 30)
        {
            counts[2]++;
        }
        else if (val >= 30 && val < 40)
        {
            counts[3]++;
        }
        else if (val >= 40 && val < 50)
        {
            counts[4]++;
        }
        else if (val >= 50 && val < 60)
        {
            counts[5]++;
        }
        else if (val >= 60 && val < 70)
        {
            counts[6]++;
        }
        else if (val >= 70 && val < 80)
        {
            counts[7]++;
        }
        else if (val >= 80 && val < 90)
        {
            counts[8]++;
        }
        else if (val >= 90 && val <= 100)
        {
            counts[9]++;
        }
    }

    // Calculate the total number of elements
    int total = n;

    // Iterate through the intervals and print out the counts and percentages
    for (int i = 0; i < 10; i++)
    {
        cout << "[" << setw(2) << i * 10 << "," << setw(2) << (i + 1) * 10 << ")";
        cout << "  {0." << setw(2) << setfill('0') << round(counts[i] * 100.0 / total) << "} ";

        // Print out the asterisks denoting the counts
        int num_asterisks = round(counts[i] * n / total);
        for (int j = 0; j < num_asterisks; j++)
        {
            cout << "*";
        }
        cout << endl;
    }
}



// Do not modify code after this line
//--------------------------------------------------------------
void read_data(double data[], std::string file_name)
{
    std::string line;
    double val;
    size_t i = 0;
    std::ifstream file_to_read(file_name);
    while(std::getline(file_to_read, line))
    {
        std::stringstream ss(line);
        while(ss >> val)
        {
            data[i] = val;
            ++i;
            if(ss.peek() == ',')
                ss.ignore();
        }
    }
    file_to_read.close();
}

void print_stats(double A[], size_t n)
{
    cout << "Min    = " << min(A,n) << endl;
    cout << "Max    = " << max(A,n) << endl;
    sort(A,A+n);
    cout << "Median = " << med(A,n) << endl;
    cout << "Averge = " << avg(A,n) << endl;
    cout << "Stdev  = " << stdev(A,n) << endl;
}

int main()
{
    size_t n1 = 30;
    double D1[n1];
    read_data(D1,"data1.csv");
    cout << "data1" << endl;
    print_stats(D1,n1);
    print_dist(D1,n1);

    size_t n2 = 101;
    double D2[n2];
    read_data(D2,"data2.csv");
    cout << endl << "data2" << endl;
    print_stats(D2,n2);
    print_dist(D2,n2);

    size_t n3 = 300;
    double D3[n3];
    read_data(D3,"data3.csv");
    cout << endl << "data3" << endl;
    print_stats(D3,n3);
    print_dist(D3,n3);

    return 0;
}