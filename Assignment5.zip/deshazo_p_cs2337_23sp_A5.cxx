//  CS 2337/L
//  2023 Spring
//  Assignment 5
//
//  Fill in your name and Buff-Id
//  Name: Preston DeShazo
//  7 digit Buff-Id: 112965
//
//  Add your code to the functions: sum_ll and print_ll
//  See the preconditions and postconditions for description of these functions.
//
//  Note: do not use the C++ std::reverse function
//  from <algorithm>
//

#include "node.h"
#include "node_sum.h"
#include <cstdlib>
#include <iostream>

using namespace std;


// Precondition: A1 contains the digits of the first number to be summed;
//               A2 contains the digits of the second number to ne summed;
//               the order of the digits in the arrays are in the same order
//               as the digits in the number to be summed; n1 is the number
//               of digits in A1; n2 is the number of digits in A2;
//               for example, an array containing {2,6,8,7} represents the
//               number 2687
// Postcondition: head_ptr is the head pointer that points to the newly 
//                created linked list containing the digits representing 
//                the sum; the order of the digits will be arranged in 
//                reversed order with respect to the summed number they
//                represent;
//                for example, if the sum is 2860, the linked list created will
//                be: head_ptr->0->6->8->2->NULL
//                See assignment 5 pdf file for the example. The code you
//                write for the function needs to follow the addition algorithm
//                shown in the assignment 5 pdf file
void sum_ll(int A1[], size_t n1, int A2[], size_t n2, node*& head_ptr)
{
    int n1_sum = 0;
    for (size_t i = 0; i < n1; i++) {
        n1_sum = n1_sum * 10 + A1[i];
    }

    int n2_sum = 0;
    for (size_t i = 0; i < n2; i++) {
        n2_sum = n2_sum * 10 + A2[i];
    }

    int sum = n1_sum + n2_sum;
    head_ptr = nullptr;
    node* tail_ptr = nullptr;

    if (sum == 0) {
        head_ptr = new node(0);
        return;
    }

    while (sum != 0) {
        int digit = sum % 10;
        sum /= 10;

        node* newnode = new node(digit);
        if (head_ptr == nullptr) {
            head_ptr = newnode;
            tail_ptr = newnode;
        } else {
            tail_ptr->set_link(newnode);
            tail_ptr = newnode;
        }
    }
}


// Precondition: head_ptr is the head pointer of the resulting linked list 
//               constructed from the summation of two numbers represented
//               by linked lists; note that the resulting linked list stores 
//               the digits of the summed number in reversed order and this
//               function process the linked list in that reversed order; for
//               example, if the summed number is 3478, then the linked list
//               passed into this function via head_ptr is: head_ptr->8->7->4->3->NULL
// Postcondition: the resulting sum is printed out from most significant digit
//                to least significant digit of the summed number; for example
//                if head_ptr points to the linked list: head_ptr->8->7->4->3->NULL, 
//                then the output (printed out in the terminal) is: 3478
//                (a new line after the last digit with no extra spaces)
void print_ll(const node* head_ptr)
{
    size_t node_count = 0;
    const node* p = head_ptr;
    while (p != nullptr) {
        node_count++;
        p = p->get_link();
    }

    // Create an array to store the data in the reverse order
    int* data_array = new int[node_count];

    // Copy the data from the linked list to the array in reverse order
    p = head_ptr;
    size_t i = node_count - 1;
    while (p != nullptr) {
        data_array[i] = p->get_data();
        i--;
        p = p->get_link();
    }

    // Print the data from the array in reverse order
    for (i = 0; i < node_count; i++) {
        cout << data_array[i];
    }
    cout << endl;
}
