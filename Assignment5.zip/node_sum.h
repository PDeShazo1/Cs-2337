//  CS 2337/L
//  20232 Spring
//  Assignment 5
//  header file for to be implemented non-member functions
//  
//  Do not modify this file
//

#ifndef NODE_SUM_H
#define NODE_SUM_H

#include "node.h"

void sum_ll(int A1[], size_t n1, int A2[], size_t n2, node*& head_ptr);
void print_ll(const node* head_ptr);

#endif