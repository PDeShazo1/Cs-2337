//  CS 2337/L
//  2023 Spring
//  Assignment 5
//
//  Do not modify this file
//

#include "node.h"
#include "node_sum.h"
#include <cstdlib>


// 2 + 5 = 7
void test1()
{
    node* head_ptr = NULL;
    int A[] = {2};
    int B[] = {5};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 9 + 9 = 18
void test2()
{
    node* head_ptr = NULL;
    int A[] = {9};
    int B[] = {9};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 1 + 9 = 10
void test3()
{
    node* head_ptr = NULL;
    int A[] = {1};
    int B[] = {9};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 9 + 1 = 10
void test4()
{
    node* head_ptr = NULL;
    int A[] = {9};
    int B[] = {1};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 24 + 65 = 89
void test5()
{
    node* head_ptr = NULL;
    int A[] = {2,4};
    int B[] = {6,5};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 11 + 29 = 40
void test6()
{
    node* head_ptr = NULL;
    int A[] = {1,1};
    int B[] = {2,9};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 123 + 234 = 357
void test7()
{
    node* head_ptr = NULL;
    int A[] = {1,2,3};
    int B[] = {2,3,4};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 555 + 445 = 1000
void test8()
{
    node* head_ptr = NULL;
    int A[] = {5,5,5};
    int B[] = {4,4,5};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 999 + 999 = 1998
void test9()
{
    node* head_ptr = NULL;
    int A[] = {9,9,9};
    int B[] = {9,9,9};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 9999 + 999 = 10998
void test10()
{
    node* head_ptr = NULL;
    int A[] = {9,9,9,9};
    int B[] = {9,9,9};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 5555 + 555 = 6110
void test11()
{
    node* head_ptr = NULL;
    int A[] = {5,5,5,5};
    int B[] = {5,5,5};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 555 + 5555 = 6110
void test12()
{
    node* head_ptr = NULL;
    int A[] = {5,5,5};
    int B[] = {5,5,5,5};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 11 + 10090 = 10101
void test13()
{
    node* head_ptr = NULL;
    int A[] = {1,1};
    int B[] = {1,0,0,9,0};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 1 + 101009 = 101010
void test14()
{
    node* head_ptr = NULL;
    int A[] = {1};
    int B[] = {1,0,1,0,0,9};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

// 101009 + 1 = 101010
void test15()
{
    node* head_ptr = NULL;
    int A[] = {1,0,1,0,0,9};
    int B[] = {1};
    sum_ll(A,sizeof(A)/sizeof(int),B,sizeof(B)/sizeof(int),head_ptr);
    print_ll(head_ptr);
    list_clear(head_ptr);
}

int main()
{
    test1();
    test2();
    test3();
    test4();
    test5();
    test6();
    test7();
    test8();
    test9();
    test10();
    test11();
    test12();
    test13();
    test14();
    test15();

    return 0;
}